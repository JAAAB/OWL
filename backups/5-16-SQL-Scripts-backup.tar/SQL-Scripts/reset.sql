drop database projects;
drop database suppliers;
